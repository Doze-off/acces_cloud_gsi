# Minhas Builds

Site moderno em GitHub Pages com builds, módulos, equipe, doação, suporte e contador global de downloads via GitHub API.

## Como funciona o contador global

- O site lê `data.json` hospedado no repositório.
- No clique de download, o frontend atualiza o arquivo usando a GitHub API.
- O total fica salvo no próprio repositório, então vale para todos os visitantes.
- Opcionalmente, você pode usar GitHub Actions para automatizar atualizações.

## O que você precisa fazer

1. Trocar `SEU_USUARIO` e `SEU_REPOSITORIO` em `config.json`.
2. Criar um **Personal Access Token** no GitHub com permissão de `contents:write`.
3. Salvar esse token no navegador com a chave `gh_pat_token`.
4. Fazer deploy no GitHub Pages.

## Estrutura

- `index.html`
- `style.css`
- `script.js`
- `api.js`
- `config.json`
- `data.json`
- `.github/workflows/update-download-stats.yml`

## Observação

GitHub Pages é estático, então a escrita global depende da GitHub API ou do GitHub Actions. Essa é uma solução prática, barata e totalmente integrada ao GitHub.
